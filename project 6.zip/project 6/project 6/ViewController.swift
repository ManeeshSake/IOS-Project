//
//  ViewController.swift
//  project 6
//
//  Created by Sake,Maneesh on 2/8/22.
//

import UIKit

class ViewController: UIViewController {
   
    
    @IBOutlet weak var testfield: UITextField!
   
    
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
    }

    @IBAction func button(_ sender: UIButton) {
        let input = Int (testfield.text!)
        if(input!%2 == 0){
            label.text = "\(input!) is even number"
        }
        else{
            label.text = "\(input!) is odd number"
        }
    }
    
}

